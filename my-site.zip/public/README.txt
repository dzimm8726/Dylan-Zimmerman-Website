Put resume.pdf and headshot.jpg in this folder.
