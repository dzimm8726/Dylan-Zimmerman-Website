import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Your Name — CS Portfolio",
  description: "Projects, resume, and contact info for Your Name."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-gray-900 antialiased">
        <main className="mx-auto max-w-5xl px-6 py-10">{children}</main>
      </body>
    </html>
  );
}
