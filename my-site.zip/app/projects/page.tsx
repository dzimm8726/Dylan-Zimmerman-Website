import ProjectCard from "@/components/ProjectCard";

const projects = [
  {
    title: "Red Solo Cup Tracker",
    description: "Vision + Arduino/servos to detect and aim liquid into a moving cup.",
    tech: ["Python", "OpenCV", "Arduino", "Raspberry Pi"],
    repo: "https://github.com/yourname/cup-tracker",
    demo: "https://your-demo-url.com"
  },
  {
    title: "Stacks Game Bot",
    description: "Automates alignment detection and taps with a servo to win Stacks.",
    tech: ["Python", "Computer Vision", "Hardware"],
    repo: "https://github.com/yourname/stacks-bot"
  }
];

export default function ProjectsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Projects</h1>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {projects.map((p) => (
          <ProjectCard key={p.title} {...p} />
        ))}
      </div>
    </div>
  );
}
