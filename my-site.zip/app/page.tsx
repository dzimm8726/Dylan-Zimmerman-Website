import Link from "next/link";

export default function HomePage() {
  return (
    <div className="space-y-10">
      <header className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Your Name</h1>
        <p className="text-lg text-gray-600">
          CS major focused on {`{ AI / systems / web }`}. I build practical, fast things.
        </p>
        <div className="flex gap-3">
          <Link href="/projects" className="rounded-xl border px-4 py-2">
            Projects
          </Link>
          <Link href="/resume" className="rounded-xl border px-4 py-2">
            Resume
          </Link>
          <Link href="/about" className="rounded-xl border px-4 py-2">
            About
          </Link>
        </div>
      </header>

      <section className="space-y-3">
        <h2 className="text-2xl font-semibold">Featured</h2>
        <p className="text-gray-600">A few highlights—see the full list on the Projects page.</p>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {/* Add a couple of ProjectCards here later if you want */}
          <div className="rounded-2xl border p-5 shadow-sm">
            <h3 className="text-xl font-semibold">Cup Tracker</h3>
            <p className="mt-2 text-gray-700">Vision + Arduino/servos to detect and aim liquid into a moving cup.</p>
            <ul className="mt-3 flex flex-wrap gap-2 text-sm text-gray-600">
              {['Python','OpenCV','Arduino','Raspberry Pi'].map(t => (
                <li key={t} className="rounded-md border px-2 py-0.5">{t}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}
