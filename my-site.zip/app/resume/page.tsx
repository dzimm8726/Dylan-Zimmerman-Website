export default function ResumePage() {
  return (
    <article className="prose">
      <h1>Resume</h1>
      <p>Put a short summary, then link a PDF.</p>
      <ul>
        <li>Education: …</li>
        <li>Skills: …</li>
        <li>Experience: …</li>
        <li>Projects: …</li>
      </ul>
      {/* Drop a PDF named resume.pdf into /public */}
      <a href="/resume.pdf" className="underline" target="_blank">Download PDF</a>
    </article>
  );
}
