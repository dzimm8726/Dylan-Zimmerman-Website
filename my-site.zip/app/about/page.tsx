export default function AboutPage() {
  return (
    <div className="space-y-3">
      <h1 className="text-3xl font-bold">About</h1>
      <p className="text-gray-700">Short bio, interests, and what you’re looking for.</p>
    </div>
  );
}
