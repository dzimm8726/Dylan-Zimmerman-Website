import Link from "next/link";

type Props = {
  title: string;
  description: string;
  tech: string[];
  repo?: string;
  demo?: string;
};

export default function ProjectCard({ title, description, tech, repo, demo }: Props) {
  return (
    <div className="rounded-2xl border p-5 shadow-sm">
      <h3 className="text-xl font-semibold">{title}</h3>
      <p className="mt-2 text-gray-700">{description}</p>
      <ul className="mt-3 flex flex-wrap gap-2 text-sm text-gray-600">
        {tech.map((t) => (
          <li key={t} className="rounded-md border px-2 py-0.5">{t}</li>
        ))}
      </ul>
      <div className="mt-4 flex gap-3">
        {repo && (
          <Link href={repo} className="underline" target="_blank" rel="noreferrer">
            Code
          </Link>
        )}
        {demo && (
          <Link href={demo} className="underline" target="_blank" rel="noreferrer">
            Demo
          </Link>
        )}
      </div>
    </div>
  );
}
