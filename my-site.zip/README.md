# My Site (Next.js + Tailwind)

## Quick start
1. Install dependencies
   ```bash
   npm install
   ```
2. Run dev server
   ```bash
   npm run dev
   ```
   Open http://localhost:3000

## Tailwind already set up
- `tailwind.config.js` and `postcss.config.js` are included.
- Tailwind directives are added in `app/globals.css`.

## Where to edit
- Homepage: `app/page.tsx`
- Layout & metadata: `app/layout.tsx`
- Projects list: `app/projects/page.tsx`
- Reusable card: `components/ProjectCard.tsx`
- Resume page: `app/resume/page.tsx`
- About page: `app/about/page.tsx`

## Deploy (Vercel)
- Push to GitHub, import into Vercel, add your domain.
- In Cloudflare DNS, add the records Vercel shows (keep orange proxy ON).

